# This is a generated file.  Do not edit.

package configurehelp;

use strict;
use warnings;
use Exporter;

use vars qw(
    @ISA
    @EXPORT_OK
    $Cpreprocessor
    );

@ISA = qw(Exporter);

@EXPORT_OK = qw(
    $Cpreprocessor
    );

$Cpreprocessor = '/home/hah/linux/f1c2000/buildroot-2020.02.4/output/host/bin/arm-buildroot-linux-gnueabi-gcc -E -isystem /home/hah/Downloads/zlib-1.2.11/build/install/include';

1;
